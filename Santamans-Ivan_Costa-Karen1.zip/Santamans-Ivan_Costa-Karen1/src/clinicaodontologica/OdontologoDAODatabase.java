package clinicaodontologica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OdontologoDAODatabase implements OdontologoDAO {
    private static final String URL = "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1";
    private static final String USER = "sa";
    private static final String PASSWORD = "";
    private static final String INSERT_ODONTOLOGO_SQL = "INSERT INTO odontologos (numero_matricula, nombre, apellido) VALUES (?, ?, ?)";
    private static final String SELECT_ALL_ODONTOLOGOS_SQL = "SELECT * FROM odontologos";

    static {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void guardarOdontologo(Odontologo odontologo) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(INSERT_ODONTOLOGO_SQL)) {
            pstmt.setInt(1, odontologo.getNumeroMatricula());
            pstmt.setString(2, odontologo.getNombre());
            pstmt.setString(3, odontologo.getApellido());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Odontologo> listarOdontologos() {
        List<Odontologo> odontologos = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(SELECT_ALL_ODONTOLOGOS_SQL);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int numeroMatricula = rs.getInt("numero_matricula");
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                odontologos.add(new Odontologo(numeroMatricula, nombre, apellido));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return odontologos;
    }
}