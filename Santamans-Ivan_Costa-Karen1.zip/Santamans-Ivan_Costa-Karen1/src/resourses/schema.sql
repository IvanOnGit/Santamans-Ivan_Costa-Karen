CREATE TABLE odontologos (
    numero_matricula INT PRIMARY KEY,
    nombre VARCHAR(50),
    apellido VARCHAR(50)
);